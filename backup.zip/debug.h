#ifndef DEBUG_H__
#define DEBUG_H__

#include "structs.h"

void printRawCalendar(Calendar);

void printRawEvent(Event);

#endif
