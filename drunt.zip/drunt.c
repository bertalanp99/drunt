#include "structs.h"
#include "dbHandler.h"
#include "debug.h"
#include "errorHandler.h"
#include "helper.h"
#include "interactiveHandler.h"

#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{ 
    shell();
    return 0;
}

