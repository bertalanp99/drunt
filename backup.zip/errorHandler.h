#ifndef ERRORHANDLER_H__
#define ERRORHANDLER_H__

void die(const char*);

#endif
