#ifndef ERRORHANDLER_H__
#define ERRORHANDLER_H__

void die(const char*, ...);

void warning(const char*, ...);

#endif
