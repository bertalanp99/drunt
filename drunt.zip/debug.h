#ifndef DEBUG_H__
#define DEBUG_H__

#include "structs.h"

void printCalendar_raw(const Calendar*);

void printVEventNode_raw(const VEventNode*);

#endif
